---
Type: Book Summary
Category: Leadership
Author: Daniel Coyle
---
What makes some teams wildly successful, while others struggle to get by? In "The Culture Code," Daniel Coyle digs deep into the secrets of high-performing organizations, from the Navy SEALs to Pixar. Through real-world examples and groundbreaking research, he uncovers the key principles that underlie their success. Whether you're a leader, entrepreneur, or just curious about the power of teamwork, "The Culture Code" will give you the tools you need to create a winning culture of your own.

(A strong culture increases net income 765 percent over ten years, according to a Harvard study of more than two hundred companies.)

Culture is a set of living relationships working toward a shared goal. It's not something you are. It's something you do. 
# Big Summary 
1. Build Safety
2. Share Vulnerability
3. Establish Purpose

# On Building Safety
Psychological safety is a key element to establish in a group. Why? Our brains are wired to prioritize social acceptance, and behavioral signals that communicates "we are not safe" destroys group chemistry, causing group performance to plummet.

However, groups that overflows with behavioral cues that communicates safety and acceptance performs extraordinarily well. Why? Psychological safety creates chemistry, fostering open communication that creates a larger web of collective intelligence. This is the strongest factor that determines group performance. 

Keyword: 
1. Psychological Safety 
2. Belonging Cues 

## The Bad Apple Experiment
Will Felps, an organizational behavior researcher at the University of South Wales in Australia, conducted the "bad apple experiment". The experiment investigated the impact of negative behavior from a group member named Nick on overall group performance. <mark style=background-color:dodgerblue><font color=snow>Results demonstrated that Nick's negative attitude not only reduced his own productivity but also had a contagious effect on other group members, leading to a decline in the group's overall performance.</font></mark>

However, the study also revealed that <mark style=background-color:dodgerblue><font color=snow>effective leadership can play a pivotal role in countering the impact of negative behavior.</font></mark> Specifically, one group leader named Jonathan responded to Nick's negativity with warmth and skill, effectively diffusing the negative impact and creating an environment conducive to open communication. By actively listening and asking simple questions, Jonathan fostered chains of insight and cooperation that ultimately led to the group's success.

The success of Jonathan's leadership lies in his adeptness at fostering a secure and interconnected environment, emphasizing the fundamental role of safety in building a robust organizational culture. 

## Belonging Cues create Psychological Safety
Groups that exhibit strong cohesion and success often display a specific mode of interaction known as "belonging cues." <mark style=background-color:dodgerblue><font color=snow>These behaviors convey a message of safety and acceptance, <u>fostering psychological safety</u> within the group.</font></mark>

According to Amy Edmondson, a psychological safety researcher at Harvard, humans possess a natural ability to perceive and respond to interpersonal signals. Our brains are wired to prioritize social acceptance, and we may feel threatened if we perceive rejection from others. <mark style=background-color:dodgerblue><font color=snow>The key to creating psychological safety is to recognize how deeply obsessed our unconscious brains are with it.</font></mark> A mere hint of belonging is not enough; one or two signals are not enough. We are built to require lots of signaling, over and over. This is why a sense of belonging is easy to destroy and hard to build.

It’s useful to look at the bad apple experiment in this light. Nick was able to disrupt the chemistry of the groups merely by sending a few cues of nonbelonging. His behavior was a powerful signal to the group—We are not safe—which immediately caused the group’s performance to fall apart. Jonathan, on the other hand, delivered a steady pulse of subtle behaviors that signaled safety. He connected individually, listened intently, and signaled the importance of the relationship. He was a wellspring of belonging cues, and the group responded accordingly.

## Belonging Cues Need to be done Again and Again
If our brains processed safety logically, we would not need this steady reminding. But our brains did not emerge from millions of years of natural selection because they process safety logically. They emerged because they are obsessively on the lookout for danger. This obsession originates in a structure deep in the core of the brain. It’s called the amygdala, and it’s our primeval vigilance device, constantly scanning the environment. When we sense a threat, the amygdala pulls our alarm cord, setting off the fight-or-flight response that floods our body with stimulating hormones, and it shrinks our perceived world to a single question: What do I need to do to survive? 

Science has recently discovered, however, that the amygdala isn’t just about responding to danger—it also plays a vital role in building social connections. It works like this: When you receive a belonging cue, the amygdala switches roles and starts to use its immense unconscious neural horsepower to build and sustain your social bonds. It tracks members of your group, tunes in to their interactions, and sets the stage for meaningful engagement. In a heartbeat, it transforms from a growling guard dog into an energetic guide dog with a single-minded goal: to make sure you stay tightly connected with your people.

On brain scans, this moment is vivid and unmistakable, as the amygdala lights up in an entirely different way. “The whole thing flips,” says Jay Van Bavel, social neuroscientist at New York University. “The moment you’re part of a group, the amygdala tunes in to who’s in that group and starts intensely tracking them. Because these people are valuable to you. They were strangers before, but they’re on your team now, and that changes the whole dynamic. It’s such a powerful switch—it’s a big top-down change, a total reconfiguration of the entire motivational and decision-making system.” All this helps reveal a paradox about the way belonging works. Belonging feels like it happens from the inside out, but in fact it happens from the outside in. Our social brains light up when they receive a steady accumulation of almost-invisible cues: We are close, we are safe, we share a future.
## Safety and Group Performance
It’s possible to predict performance by ignoring all the informational content in the exchange and focusing on a handful of belonging cues.

An experiment by Pentland and Jared Curhan analyzed a competition in which entrepreneurs pitched business ideas to a group of executives. Each participant presented their plan to the group; the group then selected and ranked the most promising plans for recommendation to an outside group of angel investors. Using sociometers to track only the cues exchanged between the presenter and the audience, Pentland found that the sociometers predicted the rankings of the most promising plans for recommendation to an outside group of angel investors with near-perfect accuracy. Notably, the content of the pitch did not matter as much as the cues with which it was delivered and received. In contrast, when the angel investors viewed the plans on paper, ignoring social signals and focusing only on informational content, they ranked the plans very differently.
 
The executives thought that they were evaluating the plans based on rational measures, but their minds subconsciously registers other crucial information, such as: How much does this person believe in this idea? How confident are they when speaking? How determined are they to make this work? And the second set of information—information that the business executives didn’t even know they were assessing—is what influenced their choice of business plans to the greatest degree. 

“This is a different way of thinking about human beings,” Pentland says. “Individuals aren’t really individuals. They’re more like musicians in a jazz quartet, forming a web of unconscious actions and reactions to complement the others in the group. You don’t look at the informational content of the messages; you look at patterns that show how the message is being sent. Those patterns contain many signals that tell us about the relationship and what’s really going on beneath the surface.”

Just hearing something said rarely results in a change in behavior. Normally, we think words matter; we think that group performance correlates with its members’ verbal intelligence and their ability to construct and communicate complex ideas. But that assumption is wrong. Words are noise. 

Pentland explains that collective intelligence is similar to the behavior of apes in a forest, where an enthusiastic ape recruits others with its behavior, prompting them to join in and collaborate. Intelligence and culture develop as individuals observe their peers experimenting with ideas, resulting in a behavioral shift. That’s how intelligence is created. That’s how culture is created. <mark style=background-color:dodgerblue><font color=snow>Group performance depends on behavior that communicates one powerful overarching idea: We are safe and connected.</font></mark>

## Real-life Examples
## How to build Belonging
"I'm giving you these comments because I have very high expectations and I know that you can reach them."
1. You are part of this group
2. This group is special, we have high standards here
3. I believe you can reach those standard

Here is a safe place to give effort. 

Personal, up close connection
Performance feedback
Big-picture perspective

First he zooms in close, creating an individualized connection. Then he operates in the middle distance, showing players the truth about their performance. Then he pans out to show the larger context in which their interaction is taking place.

If you set things up straight, the connection happens. 
Architect the greenhouse



## How to design for Belonging
Allen Curve
Closeness helps create efficiencies of connections. 

## Ideas for Action
1. Overcommunicate your listening - stream of affirmation
2. Avoid Interruptions
3. Spotlight your fallibility early on - esp. if you're a leader. Open up, show that you make mistakes, and invite input. 
4. Embrace the messenger
5. Preview future connection - future orientation
6. Overdo thank-yous
7. Be painstaking in the hiring process
8. Eliminate Bad Apples
9. Create Safe, Collision Rich Spaces
10. Make Sure Everyone Has a Voice
11. Capitalize on Threshold Moments
12. No Sandwich Feedback
13. Embrace Fun

# On Sharing Vulnerability
Vulnerability happens by design. 
Confession, discomfort and authenticity break down barriers 
Spark Cooperatioin and trust
Vulberability loop. Reciprocal vulnerability 

Normally, we think about trust and vulnerability the way we think about standing on solid ground and leaping into the unknown: first we build trust, then we leap. But science is showing us that we’ve got it backward. Vulnerability doesn’t come after trust—it precedes it. Leaping into the unknown, when done alongside others, causes the solid ground of trust to materialize beneath our feet.

Vulnerability is not a risk but a psychological requirement

Warmth 
Curiosity 

1. Overcommunicate Expectations
2. Deliver the Negative Stuff in Person
3. Focus on the first vulnerability and first disagreement
4. Listen like a trampoline
5. Candor Generating Practices
6. Flash Mentoring 
7. 

# On Establishing Purpose

## How to Lead for creativity
Lighthouse method - 
create purpose by linking where you are and where we want to be

Creativity is navigating to an unknown destination, X. This is the dimension of creativity and innovation. 

Build system that can churn through a lot of ideas to unearth the right choices. 

"Creative Engineers"

We put in some new systems, and they learned new ways of interacting. It’s strange to think that a wave of creativity and innovation can be unleashed by something as mundane as changing systems and learning new ways of interacting. But it’s true, because building creative purpose isn’t really about creativity. It’s about building ownership, providing support, and aligning group energy toward the arduous, error-filled, ultimately fulfilling journey of making something new.


Project will start out painful and frustrating. It's a *necessity* for things to be like this. This is because all creative projects are cognitive puzzles involving thousands of choices and thousands of potential ideas, and you almost never get the right answer right away. Building purpose in a creative group is not about generating a brilliant moment of breakthrough but rather about building systems that can churn through lots of ideas in order to help unearth the right choices.

This is why Catmull has learned to focus less on the ideas than on people—specifically, on providing teams with tools and support to locate paths, make hard choices, and navigate the arduous process together. “There’s a tendency in our business, as in all businesses, to value the idea as opposed to the person or a team of people,” he says. “But that’s not accurate. Give a good idea to a mediocre team, and they’ll find a way to screw it up. Give a mediocre idea to a good team, and they’ll find a way to make it better. The goal needs to be to get the team right, get them moving in the right direction, and get them to see where they are making mistakes and where they are succeeding.”

Creativity is about letting people discover what they need to do. 

BrainTrust
Next Catmull focused on creative structure. Disney had been using the conventional film development model, which worked as follows: (1) studio executives create development teams, which are charged with generating stories; (2) studio executives evaluate those ideas, decide which would be developed, and assign directors to each one; (3) directors make the movies, and executives evaluate early versions, offer notes, and occasionally create competitions called “bake-offs” to decide which film is ready for release. Catmull flipped that system on its head, removing creative power from the executives and placing it in the hands of the directors. In the new structure, the directors were responsible for coming up with their own ideas and pitching them, rather than being assigned them by studio executives. The job of the executives was not to be all-deciding bosses but rather to support the directors and their teams as they undertook the painful journey from idea to workable concept to finished film. Early in the transition, Catmull invited Disney directors and executives to Pixar to observe a BrainTrust meeting. They watched the team work together to pick a movie apart and do the hard work of rebuilding it.

The change in the energy at Disney was immediate. Disney directors called it a breath of fresh air and likened it to the fall of the Berlin Wall. It was a moment of hope, reinforced by the fact that the Disney team’s subsequent movie improvement meetings (they dubbed them the Story Trust) were judged to be the best and most useful anyone there had experienced.

We put in some new systems, and they learned new ways of interacting. It’s strange to think that a wave of creativity and innovation can be unleashed by something as mundane as changing systems and learning new ways of interacting. But it’s true, because building creative purpose isn’t really about creativity. It’s about building ownership, providing support, and aligning group energy toward the arduous, error-filled, ultimately fulfilling journey of making something new.

## Culture and Crisis
Successful cultures use crisis to crystalize their purpose. 
Cf. Pixar

## To do: 
1. Name and Rank Your Priorities
In order to move toward a target, you must first have a target. Listing your priorities, which means wrestling with the choices that define your identity, is the first step. Most successful groups end up with a small handful of priorities (five or fewer), and many, not coincidentally, end up placing their in-group relationships—how they treat one another—at the top of the list. This reflects the truth that many successful groups realize: Their greatest project is building and sustaining the group itself. If they get their own relationships right, everything else will follow.

2. Be 10 times as clear about your priorities as you think you should be. 

Leaders are inherently biased to presume that everyone in the group sees things as they do, when in fact they don’t. This is why it’s necessary to drastically overcommunicate priorities. The leaders I visited with were not shy about this. Statements of priorities were painted on walls, stamped on emails, incanted in speeches, dropped into conversation, and repeated over and over until they became part of the oxygen.


3. Figure out where you groups aim for proficiency and where it aims for creativity. 

Proficiency = doing the same thing over and over again.

time. They are about delivering machine-like reliability, and they tend to apply in domains in which the goal behaviors are clearly defined, such as service. Building purpose to perform these skills is like building a vivid map: You want to spotlight the goal and provide crystal-clear directions to the checkpoints along the way. Ways to do that include: Fill the group’s windshield with clear, accessible models of excellence. Provide high-repetition, high-feedback training. Build vivid, memorable rules of thumb (if X, then Y). Spotlight and honor the fundamentals of the skill.

Creative skills, on the other hand, are about empowering a group to do the hard work of building something that has never existed before. Generating purpose in these areas is like supplying an expedition: You need to provide support, fuel, and tools and to serve as a protective presence that empowers the team doing the work. Some ways to do that include: Keenly attend to team composition and dynamics. Define, reinforce, and relentlessly protect the team’s creative autonomy. Make it safe to fail and to give feedback. Celebrate hugely when the group takes initiative.

4. Measure what really matters
5. Use Arthifaces
6. Focus on Bar-setting behavious

Translate abstract ideas --> Concrete terms. 
