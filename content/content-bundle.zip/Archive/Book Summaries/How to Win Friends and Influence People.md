---
Type: Book Summary
Category: Influence
Author: Dale Carnegie
---
# Summary
<mark style=background-color:dodgerblue><font color=snow>Ways to make people like you:</mark></font>
1. Become interested in people
2. Smile :) 
3. Remember names
4. Talk about other's interests
5. Make the other person feel important
<br>

<mark style=background-color:crimson><font color=snow>How to Win People into Your Way of Thinking</font></mark>
1. Avoid Arguments. Winning doesn't mean real victory because they'd have resentment. 
2. Show Respect for the other person's opinions. Never say, "You're Wrong". 
3. If you're wrong, admit it quickly and emphatically. This disarms your opponent. 
5. Use the Socratic Method. Talk in a way where it gets the other person to say "yes" immediately 
6. Some people just wanna be heard. Let them talk. 
7. Wanna get them to cooperate? Let the other person feel that the idea is his or hers
8. Say "I don't blame you for feeling/ doing this". Try honestly to see things from the other person's POV
10. Appeal to nobler motives
11. Dramatise your ideas. 
12. Throw down a challenge (When all things fail)
<br>

<mark style=background-color:crimson><font color=snow>How to be an Effective Leader</font></mark>

When they suck a lot: 
1. Begin with praise and honest appreciation. Hearing unpleasant stuff is easier after that. 
2. Call attention to people's mistakes indirectly. Don't use the "sandwich method" where you praise them, then add a "but" before your criticism. That sounds insincere. Use "and" instead. 
3. Talk about your own mistakes before criticising the other person 

When you want them to move their butt: 
1. Ask questions instead of giving direct orders. 
3. Praise the slightest improvement 
4. Give the other person a fine reputation to live up to 
6. Make the other person happy about doing the thing you suggest 

When they have pride issue/ whine like a baby: 
1. Let them safe face
2. Make it easy for them to correct their faults 
3. Make the fault seem easy to correct
<br>

# Part 1: Fundamental Techniques in Handling People
## 1. If You Want to Gather Honey, Don't Kick over the Beehive
<mark style=background-color:dodgerblue><font color=snow>Rule 1: Don't criticise, condemn or complain</mark></font>

People are pussies. They will never admit faults. Why? Because they've got so little to hold onto in life that their ego and pride are something they're willing to die for. 

"We're not dealing with creatures of logic. We're dealing with creatures of emotion, creatures bristling with prejudices and motivated by pride and vanity."

<font color=skyblue>Criticism doesn't work</font>. Why?  
1. It puts a person on the defensive, <u>making them want to justify themselves</u>.
2. It wounds a person’s precious pride, hurts their sense of importance, and <u>arouses resentment</u>.

"Any fool can criticise, condemn and complain—and most fools do. But it takes character and self-control to be understanding and forgiving." 

To illustrate the point, the author referenced *Father Forgets* by W. Livingson Larned. It will trigger your heartstring. 
<br>

## 2. The Big Secret of Dealing with People
<mark style=background-color:dodgerblue><font color=snow>Rule 2: People crave to be important. Give them what they want.</font></mark> 

Why is it so transactional? Because why should anyone do anything for you? Even if there's an incentive on their part, <font color=skyblue>there's no way to get anyone to do anything unless you make them want to do it.</font> That's why you need to give them what they want. 

<font color=skyblue>The desire to be important is what they want.</font> People go batshit crazy and do all kinds of shit because of that. In fact, every act you have ever performed since the day you were born were probably performed because you wanted something. 

Charles Schwab, first president of the United States Steel Company says: 
“I consider my ability to arouse enthusiasm among my people the greatest asset I possess, and the way to develop the best that is in a person is by appreciation and encouragement... There is nothing else that so kills the ambitions of a person as criticisms from superiors. I never criticise anyone. <font color=skyblue>I believe in giving a person incentive to work.</font> So I am anxious to praise but loath to find fault. If I like anything, I am hearty in my approbation and lavish in my praise.”

Part of giving people what they want is being generous with your praise. But be genuine about it. Cause they can sense your fake-ness. People don't like flattery. 
<br>

## 3. He who Can Do This has the Whole World with Him, He who Cannot Walks a Lonely Way.
The only way to influence other people is to talk about what they want and show them how to get it. 

“If there is any one secret of success,” said Henry Ford, “it lies in the ability to get the other person’s point of view and see things from that person’s angle as well as from your own.”

The world is full of people who are grabbing and self-seeking. So the rare individual who unselfishly tries to serve others has an enormous advantage. He has little competition. Owen D. Young, a noted lawyer and one of America’s great business leaders, once said: “People who can put themselves in the place of other people who can understand the workings of their minds, need never worry about what the future has in store for them.”




# Part 2: Ways to Make People Like You 
## 4. Do this and you'll be Welcome Anywhere
<mark style=background-color:dodgerblue><font color=snow>Rule 4: Being genuinely interested in the others</font></mark>

“It is the individual who is not interested in his fellow men who has the greatest difficulties in life and provides the greatest injury to others. It is from among such individuals that all human failures spring.”

If we want to make friends, put yourself out to do things for other people—things that require time, energy, unselfishness and thoughtfulness.

Be enthusiastic. A show of interest, as with every other principle of human relations, must be sincere. It must pay off not only for the person showing the interest, but for the person receiving the attention. It is a two-way street-both parties benefit.

## 5. A Simple Way to Make a Good Impression 
<mark style=background-color:dodgerblue><font color=snow>Rule 5 = Smile</font></mark>

Professor James V. McConnell, a psychologist at the University of Michigan, expressed his feelings about a smile. “People who smile,” he said, “tend to manage teach and sell more effectively, and to raise happier children. There’s far more information in a smile than a frown. That’s why encouragement is a much more effective teaching device than punishment.”

The chairman of the board of directors of one of the largest rubber companies ‘in the United States told me that, according to his observations, people rarely succeed at anything unless they have fun doing it. This industrial leader doesn’t put much faith in the old adage that hard work alone is the magic key that will unlock the door to our desires, “I have known people,” he said, “who succeeded because they had a rip-roaring good time conducting their business. Later, I saw those people change as the fun became work. The business had grown dull, They lost all joy in it, and they failed.”

<font color=skyblue>You must have a good time meeting people if you expect them to have a good time meeting you.</font> 

You DON’T feel like smiling? Then what? <mark style=background-color:dodgerblue><font color=snow>Force yourself to smile.</font></mark> 
The psychologist and philosopher William James put it: “Action seems to follow feeling, but really action and feeling go together; and by regulating the action, which is under the more direct control of the will, we can indirectly regulate the feeling, which is not. “Thus the sovereign voluntary path to cheerfulness, if our cheerfulness be lost, is to sit up cheerfully and to act and speak as if cheerfulness were already there. . ..” 

Every body in the world is seeking happiness—and there is one sure way to find it. That is by controlling your thoughts. Happiness doesn’t depend on outward conditions. It depends on inner conditions. Most folks are about as happy as they make up their minds to be. 

<mark style=background-color:dodgerblue><font color=snow>Your smile is a messenger of your good will.</mark></font> Your smile brightens the lives of all who see it. To someone who has seen a dozen people frown, scowl or turn their faces away, your smile is like the sun breaking through the clouds. Especially when that someone is under pressure from his bosses, his customers, his teachers or parents or children, a smile can help him realise that all is not hopeless—that there is joy in the world.

## 6. If You Don't Do This, You're Headed For Trouble
<mark style=background-color:dodgerblue><font color=snow>Rule 6 = Remember their name </mark></font>

We should be aware of the magic contained in a name and realise that this single item is wholly and completely owned by the person with whom we are dealing and nobody else. The name sets the individual apart; it makes him or her unique among all others. The information we are imparting or the request we are making takes on a special importance when we approach the situation with the name of the individual. From the waitress to the senior executive, the name will work magic as we deal with others.

A person's name is to that person the sweetest and most important sound in any language. 


## 7. An Easy Way to Become a Good Conversationalist
<mark style=background-color:dodgerblue><font color=snow>Rule 7 = Be a good listener </font></mark>

Many people made unfavourable impression because they don't listen attentively. If you want to know how to make people shun you and laugh at you behind your back and even despise you, here is the recipe: Never listen to anyone for long. Talk incessantly about yourself. If you have an idea while the other person is talking, DON’T wait for him or her to finish: bust right in and interrupt in the middle of a sentence.

Remember that the people you are talking to are a hundred times more interested in themselves and their wants and problems than they are in you and your problems. <font color=skyblue>A person’s toothache means more to that person than a famine in China which kills a million people. A boil on one’s neck interests one more than forty earthquakes in Africa.</font> Think of that the next time you start a conversation.
<br>

## 8. How to Interest People
Talk about things that interest them.

## 9. How to Make People Like You Instantly
<mark style=background-color:dodgerblue><font color=snow> Rule 9: Make them feel important</font></mark>

Little phrases such as “I’m sorry to trouble you,” “Would you be so kind as to ----?” “Won’t you please?” “Would you mind?” “Thank you”—little courtesies like these oil the cogs of the monotonous grind of everyday life—and, incidentally, they are the hallmark of good breeding.

# Part 3: How to Win People to Your Way of Thinking 
## 10. You Can't Win An Argument 
<mark style=background-color:dodgerblue><font color=snow>Rule 10: Avoid Arguments</mark></font>

You can’t win an argument. Even if you win, it's a lose-lose situation. Well, suppose you triumph over the other man and shoot his argument full of holes and prove that he is non compos mentis. Then what? You will feel fine. But what about him? 

<font color=skyblue>You have made him feel inferior. You have hurt his pride. He will resent your triumph. And a man convinced against his will Is of the same opinion still.</font>

It's an <font color=skyblue>empty victory because you will never get your opponent’s good will.</font> So figure it out for yourself. <font color=skyblue>Which would you rather have, an academic, theatrical victory or a person’s good will? You can seldom have both.</font>
<br>
<mark style=background-color:dodgerblue><font color=snow>How to keep a disagreement from becoming an argument?</font></mark>

1. Suppress the first instinct to be defensive. 

3. Be thankful that the disagreement has been brought to your attention. 
4. <mark style=background-color:dodgerblue><font color=snow>Give your opponents a chance to talk. Let them finish.</font></mark> 
5. Understand what they're saying. 
6. Try to build bridges of understanding. <mark style=background-color:dodgerblue><font color=snow>Look for areas of agreement.</font></mark> When you have heard your opponents out, dwell first on the points and areas on which you agree. 
7. Be honest, <mark style=background-color:dodgerblue><font color=snow>Look for areas where you can admit error and say so.</font></mark> Apologise for your mistakes. It will help <mark style=background-color:dodgerblue><font color=snow>disarm your opponents</font></mark> and reduce defensiveness. 
8. Promise to <mark style=background-color:dodgerblue><font color=snow>think over your opponents’ ideas and study them carefully</font></mark>. And mean it. Your opponents may be right. It is a lot easier at this stage to agree to think about their points than to move rapidly ahead and find yourself in a position where your opponents can say: “We tried to tell you, but you wouldn’t listen.” 
9. <mark style=background-color:dodgerblue><font color=snow>Thank your opponents sincerely for their interest.</font></mark> Anyone who takes the time to disagree with you is interested in the same things you are. Think of them as people who really want to help you, and you may turn your opponents into friends. 
10. Postpone action to give both sides time to think through the problem. Suggest that a new meeting be held later that day or the next day, when all the facts may be brought to bear. 

Ask yourself some hard questions: 
Could my opponents be right? Partly right? Is there truth or merit in their position or argument? Is my reaction one that will relieve the problem, or will it just relieve any frustration? Will my reaction drive my opponents further away or draw them closer to me? Will my reaction elevate the estimation good people have of me? Will I win or lose? What price will I have to pay if I win? If I am quiet about it, will the disagreement blow over? Is this difficult situation an opportunity for me?
<br>


## 11. A Sure way of Making Enemies and How to Avoid It
<mark style=background-color:dodgerblue><font color=snow>Telling people that they're wrong straight up doesn't work.</font></mark> 
We sometimes find ourselves changing our minds without any resistance or heavy emotion, but if we are told we are wrong, we resent the imputation and harden our hearts. We are incredibly heedless in the formation of our beliefs, but find ourselves filled with an illicit passion for them when anyone proposes to rob us of their companionship. It is obviously not the ideas themselves that are dear to us, but our self-esteem which is threatened. We like to continue to believe what we have been accustomed to accept as true, and the resentment aroused when doubt is cast upon any of our assumptions leads us to seek every manner of excuse for clinging to it. The result is that most of our so-called reasoning consists in finding arguments for going on believing as we already do.

‘Our dealership has made so many mistakes that I am frequently ashamed. We may have erred in your case. Tell me about it.’ “This approach becomes quite disarming, and by the time the customer releases his feelings, he is usually much more reasonable when it comes to settling the matter. In fact, several customers have thanked me for having such an understanding attitude. And two of them have even brought in friends to buy new cars. In this highly competitive market, we need more of this type of customer, and I believe that showing respect for all customers’ opinions and treating them diplomatically and courteously will help beat the competition.”
<br>
<mark style=background-color:dodgerblue><font color=snow>You will never get into trouble by admitting that you **may** be wrong.</font></mark> 
That will stop all argument and inspire your opponent to be just as fair and open and broad-minded as you are. It will make him want to admit that he, too, may be wrong.

When we are wrong, we may admit it to ourselves. And if we are handled gently and tactfully, we may admit it to others and even take pride in our frankness and broad-mindedness. But not if someone else is trying to ram the unpalatable fact down our esophagus.
<br><br>


## 12. If You're Wrong, Admit It
It takes great courage to admit that you're wrong. But if you do it, it disarms people. <br>

## 13. A Drop of Honey 
Lincoln said that, in effect, over a hundred years ago. Here are his words: It is an old and true maxim that “a drop of honey catches more flies than a gallon of gall.” So with men, if you would win a man to you cause, first convince him that you are his sincere friend. Therein is a drop of honey that catches his heart; which, say what you will, is the great high road to his reason.
<br>

## 14. The Secret of Socrates
Begin by emphasizing—and keep on emphasizing—the things on which you agree. Keep emphasizing, if possible, that you are both striving for the same end and that your only difference is one of method and not of purpose.

The psychological patterns here are quite clear. When a person says “No” and really means it, he or she is doing far more than saying a word of two letters. The entire organism—glandular, nervous, muscular—gathers itself together into a condition of rejection. There is, usually in minute but sometimes in observable degree, a physical withdrawal or readiness for withdrawal. The whole neuromuscular system, in short, sets itself on guard against acceptance. When, to the contrary, a person says “Yes,” none of the withdrawal activities takes place. The organism is in a forward—moving, accepting, open attitude. Hence the more “Yeses” we can, at the very outset, induce, the more likely we are to succeed in capturing the attention for our ultimate proposal. It is a very simple technique—this yes response. And yet, how much it is neglected! It often seems as if people get a sense of their own importance by antagonising others at the outset. Get a student to say “No” at the beginning, or a customer, child, husband, or wife, and it takes the wisdom and the patience of angels to transform that bristling negative into an affirmative.

This is called the <mark style=background-color:dodgerblue><font color=snow>Socratic Method</font></mark>.
It's based upon getting a “yes, yes” response. He asked questions with which his opponent would have to agree. He kept on winning one admission after another until he had an armful of yeses. He kept on asking questions until finally, almost without realising it, his opponents found themselves embracing a conclusion they would have bitterly denied a few minutes previously.





## 15. The Safety Valve in Handling Complaints 
Must people trying to win others to their way of thinking do too much talking themselves. Let the other people talk themselves out. They know more about their business and problems than you do. So ask them questions. Let them tell you a few things.

If you disagree with them you may be tempted to interrupt. But DON’T. It is dangerous. They won’t pay attention to you while they still have a lot of ideas of their own <font color=skyblue>crying for expression.</font> So listen patiently and with an open mind. Be sincere about it. Encourage them to express their ideas fully.


## 16. How to Get Cooperation 
No one likes to feel that he or she is being sold something or told to do a thing. <mark style=background-color:dodgerblue><font color=snow>We much prefer to feel that we are buying of our own accord or acting on our own ideas.</font></mark> We like to be consulted about our wishes, our wants, our thoughts.

“I had urged him to buy what I thought he ought to have. Then I changed my approach completely. I urged him to give me his ideas. This made him feel that he was creating the designs. And he was. I didn’t have to sell him. He bought.”
<br>

## 17. A Formula That Will Work Wonders For You 
There is a reason why the other man thinks and acts as he does. Ferret out that reason—and you have the key to his actions, perhaps to his personality Try honestly to put yourself in his place. If you say to yourself, “How would I feel, how would I react if I were in his shoes?” you will save yourself time and irritation, for “by becoming interested in the cause, we are less likely to dislike the effect.” And, in addition, you will sharply increase your skill in human relationships.

“Cooperativeeness in conversation is achieved when you show that you consider the other person’s ideas and feelings as important as your own. Starting your conversation by giving the other person the purpose or direction of your conversation, governing what you say by what you would want to hear if you were the listener, and accepting his or her viewpoint will encourage the listener to have an open mind to your ideas.”

“Having a good time, boys? What are you going to cook for supper? . . . I loved to build fires myself when I was a boy—and I still love to. But you know they are very dangerous here in the park. I know you boys DON’T mean to do any harm, but other boys aren’t so careful. They come along and see that you have built a fire; so they build one and DON’T put it out when they go home and it spreads among the dry leaves and kills the trees. We won’t have any trees here at all if we aren’t more careful, You could be put in jail for building this fire. But I DON’T want to be bossy and interfere with your pleasure. I like to see you enjoy yourselves; but won’t you please rake all the leaves away from the fire right now—and you’ll be careful to cover it with dirt, a lot of dirt, before you leave, won’t you? And the next time you want to have some fun, won’t you please build your fire over the hill there in the sandpit? It can’t do any harm there. . . . Thanks so much, boys. Have a good time.” What a difference that kind of talk made! It made the boys want to cooperate. No sullenness, no resentment. They hadn’t been forced to obey orders. They had saved their faces. They felt better and I felt better because I had handled the situation with consideration for their point of view.




## 18. What Everybody Wants 
Be sympathetic with the other person's ideas and desires

Wouldn’t you like to have a magic phrase that would stop arguments, eliminate ill feeling, create good will, and make the other person listen attentively? Yes? All right. Here it is: <mark style=background-color:dodgerblue><font color=snow>“I DON’T blame you one iota for feeling as you do. If I were you I would undoubtedly feel just as you do.”</font></mark>



## 19. An Appeal That Everybody Likes
The fact is that <mark style=background-color:dodgerblue><font color=snow>all people you meet have a high regard for themselves and like to be fine and unselfish in their own estimation.</mark></font> 

J. Pierpont Morgan observed, in one of his analytical interludes, that a person usually has two reasons for doing a thing: one that sounds good and a real one. The person himself will think of the real reason. You DON’T need to emphasize that. But all of us, being idealists at heart, like to think of motives that sound good. So, in order to change people, appeal to the nobler motives.

To put it differently and perhaps more clearly, people are honest and want to discharge their obligations. The exceptions to that rule are comparatively few, and I am convinced that the individuals who are inclined to chisel will in most cases react favorably if you make them feel that you consider them honest, upright and fair.”

Appeal to nobler motives.

## 20. The Movies Do It, TV Does It...Why Don't You Do It? 
The printing of that book dramatized the fact that the Bulletin carried an enormous amount of interesting reading matter. It conveyed the facts more vividly, more interestingly, more impressively, than pages of figures and mere talk could have done. This is the day of dramatization. Merely stating a truth isn’t enough. The truth has to be made vivid, interesting, dramatic. You have to use showmanship. The movies do it. Television does it. And you will have to do it if you want attention.

Television commercials abound with examples of the use of dramatic techniques in selling products. Sit down one evening in front of your television set and analyze what the advertisers do in each of their presentations. You will note how an antacid medicine changes the color of the acid in a test tube while its competitor doesn’t, how one brand of soap or detergent gets a greasy shirt clean when the other brand leaves it gray. You’ll see a car maneuver around a series of turns and curves – far better than just being told about it. Happy faces will show contentment with a variety of products. All of these dramatize for the viewer the advantages offered by whatever is being sold—and they do get people to buy them.

“Last week I called on a neighborhood grocer and saw that the cash registers he was using at his checkout counters were very old-fashioned. I approached the owner and told him: ‘You are literally throwing away pennies every time a customer goes through your line.’ With that I threw a handful of pennies on the floor. He quickly became more attentive. The mere words should have been of interest to him, but the sound of Pennies hitting the floor really stopped him. I was able to get an order from him to replace all of his old machines.”

“I was presenting the same facts this time that I had presented previously. But this time I was using dramatization, showmanship—and what a difference it made.”

## 21. When Nothing Else Works, Try This
Frederic Herzberg, one of the great behavioral scientists, concurred. He studied in depth the work attitudes of thousands of people ranging from factory workers to senior executives. What do you think he found to be the most motivating factor—the one facet of the jobs that was most stimulating? Money? Good working conditions? Fringe benefits? No—not any of those. The one major factor that motivated people was the work itself. If the work was exciting and interesting, the worker looked forward to doing it and was motivated to do a good job. That is what every successful person loves: the game. The chance for self- expression. The chance to prove his or her worth, to excel, to win. That is what makes foot-races and hog-calling and pie-eating contests. The desire to excel. The desire for a feeling of importance. PRINCIPLE 12—Throw down a challenge.

# Part 4: Be a Leader: How to Change People Without Giving Offence Or Arousing Resentment
## 22. If You Must Find Fault, This is The Way To Begin 
Begin with praise and honest appreciation. 
It is always easier to listen to unpleasant things after we have heard some praise of our good points.

Dorothy Wrublewski, a branch manager of the Fort Monmouth, New Jersey, Federal Credit Union, reported to one of our classes how she was able to help one of her employees become more productive. “We recently hired a young lady as a teller trainee. Her contact with our customers was very good. She was accurate and efficient in handling individual transactions. The problem developed at the end of the day when it was time to balance out. “The head teller came to me and strongly suggested that I fire this woman. ‘she is holding up everyone else because she is so slow in balancing out. I’ve shown her over and over, but she can’t get it. She’s got to go.’ “The next day I observed her working quickly and accurately when handling the normal everyday transactions, and she was very pleasant with our customers. “It didn’t take long to discover why she had trouble balancing out. After the office closed, I went over to talk with her. She was obviously nervous and upset. I praised her for being so friendly and outgoing with the customers and complimented her for the accuracy and speed used in that work. I then suggested we review the procedure we use in balancing the cash drawer. Once she realized I had confidence in her, she easily followed my suggestions and soon mastered this function. We have had no problems with her since then.” Beginning with praise is like the dentist who begins his work with Novocain. The patient still gets a drilling, but the Novocain is pain-killing.

## 23. How to Criticise and Not Be Hated For It
Call attention to people's mistakes indirectly. 

Many people begin their criticism with sincere praise followed by the word “but” and ending with a critical statement. For example, in trying to change a child’s careless attitude toward studies, we might say, “We’re really proud of you, Johnnie, for raising your grades this term. But if you had worked harder on your algebra, the results would have been better.” In this case, Johnnie might feel encouraged until he heard the word “but.” He might then question the sincerity of the original praise. To him, the praise seemed only to be a contrived lead-in to a critical inference of failure. Credibility would be strained, and we probably would not achieve our objectives of changing Johnnie’s attitude toward his studies. This could be easily overcome by changing the word “but” to “and.” “We’re really proud of you, Johnnie, for raising your grades this term, and by continuing the same conscientious efforts next term, your algebra grade can be up with all the others.” Now, Johnnie would accept the praise because there was no follow-up of an inference of failure. We have called his attention to the behavior we wished to change indirectly and the chances are he will try to live up to our expectations. Calling attention to one’s mistakes indirectly works wonders with sensitive people who may resent bitterly any direct criticism. Marge Jacob of Woonsocket, Rhode Island, told one of our classes how she convinced some sloppy construction workers to clean up after themselves when they were building additions to her house.

Don't use "but", use "and". 

“Gentlemen,” he started, “you are leaders. You will be most effective when you lead by example. You must be the example for your men to follow. You know what the army regulations say about haircuts. I am going to get my hair cut today, although it is still much shorter than some of yours. You look at yourself in the mirror, and if you feel you need a haircut to be a good example, we'll arrange time for you to visit the post barbership.” The result was predictable. Several of the candidates did look in the mirror and went to the barbershop that afternoon and received “regulation” haircuts. Sergeant Kaiser commented the next morning that he already could see the development of leadership qualities in some of the members of the squad.




## 24. Talk About Your Own Mistakes First
Talk about your own mistakes before Criticising the Other Person. 




## 25. No One Likes To Take Orders
Ask questions instead of giving direct orders.
How could he have handled it differently? If he had asked in a friendly way, “Whose car is in the driveway?” and then suggested that if it were moved, other cars could get in and out, the student would have gladly moved it and neither he nor his classmates would have been upset and resentful. Asking questions not only makes an order more palatable; it often stimulates the creativity of the persons whom you ask. People are more likely to accept an order if they have had a part in the decision that caused the order to be issued. When Ian Macdonald of Johannesburg, South Africa, the general manager of a small manufacturing plant specializing in precision machine parts, had the opportunity to accept a very large order, he was convinced that he would not meet the promised delivery date. The work already scheduled in the shop and the short completion time needed for this order made it seem impossible for him to accept the order. Instead of pushing his people to accelerate their work and rush the order through, he called everybody together, explained the situation to them, and told them how much it would mean to the company and to them if they could make it possible to produce the order on time.




## 26. Let the Other Person Save Face
 Years ago the General Electric Company was faced with the delicate task of removing Charles Steinmetz from the head of a department. Steinmetz, a genius of the first magnitude when it came to electricity, was a failure as the head of the calculating department. Yet the company didn’t dare offend the man. He was indispensable—and highly sensitive. So they gave him a new title. They made him Consulting Engineer of the General Electric Company—a new title for work he was already doing—and let someone else head up the department.

“I recently decided to let our seasonal personnel go with a little more tact and consideration. So I call each one in only after carefully thinking over his or her work during the winter. And I’ve said something like this: ‘Mr. Smith, you’ve done a fine job (if he has). That time we sent you to Newark, you had a tough assignment. You were on the spot, but you came through with flying colors, and we want you to know the firm is proud of you. You’ve got the stuff—you’re going a long way, wherever you’re working. This firm believes in you, and is rooting for you, and we DON’T want you to forget it.’ “Effect? The people go away feeling a lot better about being fired. They DON’T feel ‘let down.’ They know if we had work for them, we’d keep them on. And when we need them again, they come to us with a keen personal affection.”

“Instead, he thanked me for my work and remarked that it was not unusual for a person to make an error on a new project and that he had confidence that the repeat survey would be accurate and meaningful to the company. He Assured me, in front of all my colleagues, that he had faith in me and I knew I had done my best, and that my lack of experience, not my lack of ability, was the reason for the failure. I left that meeting with my head in the air and with the determination that I would never let that boss of mine down again.”





## 27. How To Spur People On To Success 
Remember, we all crave appreciation and recognition, and will do almost anything to get it. But nobody wants insincerity. Nobody wants flattery. Let me repeat: The principles taught in this book will work only when they come from the heart. I am not advocating a bag of tricks. I am talking about a new way of life. Talk about changing people. If you and I will inspire the people with whom we come in contact to a realization of the hidden treasures they possess, we can do far more than change people. We can literally transform them. Exaggeration? Then listen to these sage words from William James, one of the most distinguished psychologists and philosophers America has ever produced: Compared with what we ought to be, we are only half awake. We are making use of only a small part of our physical and mental resources. Stating the thing broadly, the human individual thus lives far within his limits. He possesses powers of various sorts which he habitually fails to use. Yes, you who are reading these lines possess powers of various sorts which you habitually fail to use; and one of these powers you are probably not using to the fullest extent is your magic ability to praise people and inspire them with a realization of their latent possibilities. Abilities wither under criticism; they blossom under encouragement. To become a more effective leader of people, apply . . .

## 28. Give a Dog a Good Name 
Give the other person a fine reputation to live up to. 
“Bill,” he said, “you are a fine mechanic. You have been in this line of work for a good number of years. You have repaired many vehicles to the customers’ satisfaction. In fact, we’ve had a number of compliments about the good work you have done. Yet, of late, the time you take to complete each job has been increasing and your work has not been up to your own old standards. Because you have been such an outstanding mechanic in the past, I felt sure you would want to know that I am not happy with this situation, and perhaps jointly we could find some way to correct the problem.”

The average person can be led readily if you have his or her respect and if you show that you respect that person for some kind of ability. 

“Jack,” he said, “since I left this morning I realized I hadn’t given you the entire picture of our new line, and I would appreciate some of your time to tell you about the points I omitted. I have respected the fact that you are always willing to listen and are big enough to change your mind when the facts warrant a change.” Could Jack refuse to give him another hearing? Not with that reputation to live up to.

“Tommy, I understand you are a natural leader. I’m going to depend on you to help me make this class the best class in the fourth grade this year.” She reinforced this over the first few days by complimenting Tommy on everything he did and commenting on how this showed what a good student he was. With that reputation to live up to, even a nine-year-old couldn’t let her down—and he didn’t. If you want to excel in that difficult leadership role of changing the attitude or behavior of others, use . . .

## 29. Make the Fault Seem Easy to Correct
Use encouragement. Make the fault seem easy to connect. 
A bachelor friend of mine, about forty years old, became engaged, and his fiancée persuaded him to take some belated dancing lessons. “The Lord knows I needed dancing lessons,” he confessed as he told me the story, “for I danced just as I did when I first started twenty years ago. The first teacher I engaged probably told me the truth. She said I was all wrong; I would just have to forget everything and begin all over again. But that took the heart out of me. I had no incentive to go on. So I quit her.

“The next teacher may have been lying, but I liked it. She said nonchalantly that my dancing was a bit old-fashioned perhaps, but the fundamentals were all right, and she assured me I wouldn’t have any trouble learning a few new steps. The first teacher had discouraged me by emphasizing my mistakes. This new teacher did the opposite. She kept praising the things I did right and minimizing my errors. ‘You have a natural sense of rhythm,’ she assured me. ‘You really are a natural-born dancer.’ Now my common sense tells me that I always have been and always will be a fourth-rate dancer; yet, deep in my heart, I still like to think that maybe she meant it. To be sure, I was paying her to say it; but why bring that up?

“At any rate, I know I am a better dancer than I would have been if she hadn’t told me I had a natural sense of rhythm. That encouraged me. That gave me hope. That made me want to improve.”

Tell your child, your spouse, or your employee that he or she is stupid or dumb at a certain thing, has no gift for it, and is doing it all wrong, and you have destroyed almost every incentive to try to improve. But use the opposite technique—be liberal with your encouragement, make the thing seem easy to do, let the other person know that you have faith in his ability to do it, that he has an undeveloped flair for it—and he will practice until the dawn comes in the window in order to excel.

This helps others improve. 

## 30. Making People Glad To Do What You Want 
Make the other person happy about doing the thing you suggest 

## 19. If You Must Find Fault, This Is The Way 
## 20. How to Criticize and Not be Hated For it 
## 21. Talk About Your Own Mistakes First
## 22. No One Likes To Take Orders 
Frame it as a question. People like to be consulted. 
## 23. Let The Other Person Save Face
## 24. How to Spur People to Success
## 25. Give a Dog a Good Name
Give them something to live up to. Leverage that "standard" you set on them. 
## 26. Make the Fault Seem Easy to Correct 
If you tell them they suck too much, they don't wanna change cause it's too discouraging.. 
## 27. Making People Glad To Do What You Want 
William Jennings Bryan, secretary of state, Bryan, the peace advocate, longed to go. He saw a chance to perform a great service and make his name immortal. But Wilson appointed another man, his intimate friend and advisor Colonel Edward M. House; and it was House’s thorny task to break the unwelcome news to Bryan without giving him offense. “Bryan was distinctly disappointed when he heard I was to go to Europe as the peace emissary,” Colonel House records in his diary. “He said he had planned to do this himself . . . “I replied that the President thought it would be unwise for anyone to do this officially, and that his going would attract a great deal of attention and people would wonder why he was there. . ..” You see the intimation? House practically told Bryan that he was too important for the job—and Bryan was satisfied.

**Leverage their desire to be important.**

Making titles for people. Te teacher beh song boys running across her lawn and maker her grass die. She tried criticism and coaxing. Didn't work. But it worked when she made one of the guys her detective to get the guys off her lawn. It worked. He event built a bonfire in the backyard, heated an iron red hot, and threatened to brand any boy who stepped on the lawn. 
bruh. 