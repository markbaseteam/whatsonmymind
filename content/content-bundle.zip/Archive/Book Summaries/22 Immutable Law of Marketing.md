---
Type: Book Summary
Category: Marketing
Author: 
- Al Ries
- Jack Trout
---
There are laws of marketing. Most of them are common sense. 

Here are the 22 Immutable Laws of Marketing
1. [[22 Immutable Law of Marketing#The Law of Leadership|The Law of Leadership]]
2. [[22 Immutable Law of Marketing#The Law of Category|The Law of Category]]
3. [[22 Immutable Law of Marketing#The Law of the Mind|The Law of the Mind]] 
4. [[22 Immutable Law of Marketing#The Law of Perception|The Law of Perception]]
5. [[22 Immutable Law of Marketing#The Law of Focus|The Law of Focus]]
6. [[22 Immutable Law of Marketing#The Law of Exclusivity|The Law of Exclusivity]]
7. [[22 Immutable Law of Marketing#The Law of the Ladder|The Law of the Ladder]]
8. Law of Duality
9. Law of the Opposite
10. Law of Division
11. Law of Perspective
12. Law of Line Extension
13. Law of Sacrifice
14. Law of Attributes
15. Law of Candor
16. Law of Singularity
17. Law of Unpredictability
18. Law of Success
19. law of Failure
20. Law of Hype
21. Law of Acceleration
22. [[22 Immutable Law of Marketing#The Law of Resources|The Law of Resources]]


# The Law of Leadership: Be the first 
<mark style=background-color:dodgerblue><font color=snow> It's better to be first than to be better </mark></style> 

<font color=skyblue><u>People remember the first.</u> </font>
The leading brand always the first brand into the prospect’s mind. It's easier to get into the mind first than to try to convince someone you have a better product than the one that did get there first.

<font color=skyblue><u>The first brand's name becomes generic.</u></font>
How many people ask for cellophane tape instead of Scotch tape? Not many. Most people use brand names when they become generic: Band-Aid, Fiberglas, Formica, Gore-Tex, Jello, Krazy Glue, Q-tips, Saran Wrap, Velcro—to name a few.

<font color=skyblue><u>The first product in people's mind = superior</u></font>
Benchmarking doesn't work. No use telling people you're "better"
People perceive the first product into the mind as superior. 

<u><font color=skyblue>The first brand has the most sales</font></u>
Not only does the first brand usually become the leader, but also the sales order of follow-up brands often matches the order of their introductions.

# The Law of Category: Invent the category you can be first in
<mark style=background-color:dodgerblue><font color=snow> If you can't be first in a category, set up in a new category you can be first in </mark></style> 

This is counter to classic marketing thinking, which is brand oriented: How do I get people to prefer my brand? Forget the brand. Think categories. Prospects are on the defensive when it comes to brands. Everyone talks about why their brand is better. But <font color=skyblue>prospects have an open mind when it comes to categories. Everyone is interested in what’s new. Few people are interested in what’s better.</font>

You can turn an "also-ran" into a winner by inventing a new category. There are many different ways to be first. Dell got into the crowded personal computer field by being the first to sell computers by phone. Today Dell is a $900 million company.

How to do this? When you launch a new product, think: “First what?” "What category is this new product first in?"

When you’re the first in a new category, promote the category. 
In essence, you have <font color=skyblue>no competition.</font> Why? Cause you're the first here. 


# The Law of the Mind: Be the first in people's mind
<mark style=background-color:dodgerblue><font color=snow> It's better to be first in the mind than to be first in the marketplace </mark></style> 

The world’s first personal computer was the MITS Altair 8800. The law of leadership would suggest that the MITS Altair 8800  ought to be the No. 1 personal computer brand. Unfortunately, the product is no longer with us. IBM wasn’t first in the marketplace with the mainframe computer. Remington Rand was first, with UNIVAC. But thanks to a massive marketing effort, IBM got into the mind first and won the computer battle early.

This is not a contradiction to the first law. <font color=skyblue>Being first in the marketplace is important only to the extent that it allows you to get in the mind first.</font>

The law of the mind follows from the law of perception. If marketing is a battle of perception, not product, then the mind takes precedence over the marketplace.<font color=skyblue>The single most wasteful thing you can do in marketing is try to change a mind.</font> If you want to make a big impression on another person, you cannot worm your way into their mind and then slowly build up a favorable opinion over a period of time. The mind doesn’t work that way. You have to blast your way into the mind. The reason you blast instead of worm is that people don’t like to change their minds. Once they perceive you one way, that’s it. They kind of file you away in their minds as a certain kind of person. You cannot become a different person in their minds.

That's why you must have money and put that money into Marketing. Apple’s problem in getting into its prospects’ minds was helped by its simple, easy-to-remember name, but it is undeniable that a huge part of their success is attributed to the $91,000 contributed by Mike Markkula. In the early days, five personal computers were in position on the launching pad: Apple II, Commodore Pet, IMSAI 8080, MITS Altair 8800, and Radio Shack TRS-80. Ask yourself, which name is the simplest and easiest to remember?

# The Law of Perception: Perception is reality
<mark style=background-color:dodgerblue><font color=snow> Marketing is a battle of perception </mark></font>

We think that being the best means everything, but that's wrong. In Marketing, facts don't matter. Perception does. The perception is the reality. Everything else is an illusion.

Our buying decisions is also based on second-hand perceptions. Instead of using their own perceptions, they base their buying decisions on someone else’s perception of reality. This is the “everybody knows” principle. Everybody knows that the Japanese make higher-quality cars than the Americans do. So people make buying decisions based on the fact that everybody knows the Japanese make higher-quality cars. When you ask shoppers whether they have had any personal experience with a product, most often they say they haven’t. And, more often than not, <font color=skyblue>their own experience is often twisted to conform to their perceptions.</font> If you have had a bad experience with a Japanese car, you’ve just been unlucky, because everybody knows the Japanese make high-quality cars. Conversely, if you have had a good experience with an American car, you’ve just been lucky, because everybody knows that American cars are poorly made.

## Case Study: Honda in the US and Honda in Japan 
Honda sales in Japan and the US is different. In America, the 3 largest-selling Japanese-imported cards are Honda, Toyota, and Nissan, and Honda's the leader among them. But in Japan, Honda's the 3rd place behind Toyota and Nissan. What's the different? The perception in customer's mind. 

Why? If you told friends in New York you bought a Honda, they might ask you, “What kind of car did you get? a Civic? an Accord? a Prelude?” If you told friends in Tokyo you bought a Honda, they might ask you, “What kind of motorcycle did you buy?” In Japan, Honda got into customers’ minds as a manufacturer of motorcycles, and apparently most people don’t want to buy a car from a motorcycle company.
## Case Study: The sad case of Audi
On November 23, 1986, CBS broadcast a “60 Minutes” segment called “Out of Control.” It called attention to a number of complaints about Audi’s “unintended acceleration.” American sales of Audis fell through the floorboards—from 60,000 in 1986 to 12,000 in 1991. But have you ever personally had any problems with “unintended acceleration” while test-driving an Audi? It is unlikely. Every single automobile expert who has tested the car has failed to duplicate the complaint. Yet the perception lingers on.

Recently Audi has been running advertisements comparing its cars to comparable cars made by Mercedes-Benz and BMW. According to the ads, German automotive experts rated Audi cars ahead of both Mercedes and BMW. Do you believe that? Probably not. Is it true? Does it matter? Marketing is not a battle of products. It’s a battle of perceptions.


# The Law of Focus: Own a word
<mark style=background-color:dodgerblue><font color=snow> The most powerful concept in marketing is owning a word in the prospect's mind </font></mark>

<font color=skyblue>A company can become incredibly successful if it can find a way to own a word in the mind of the prospect.</font> Not a complicated word. Not an invented one. The simple words are best, words taken right out of the dictionary. This is the law of focus. <font color=skyblue>You “burn” your way into the mind by narrowing the focus to a single word or concept.</font> 

Words come in different varieties. They can be benefit related (cavity prevention), service related (home delivery), audience related (younger people), or sales related (preferred brand).<font color=skyblue>**But the most effective words are simple and benefit-oriented.**</font> No matter how complicated the product, no matter how complicated the needs of the market, <font color=skyblue>it’s always better to focus on one word or benefit rather than two or three or four.</font> The essence of marketing is narrowing the focus. You become stronger when you reduce the scope of your operations. You can’t stand for something if you chase after everything.

Federal Express was able to put the word overnight into the minds of its prospects because it sacrificed its product line and focused on overnight package delivery only. The leader owns the word that stands for the category. For example, IBM owns computer. This is another way of saying that the brand becomes a generic name for the category. “We need an IBM machine.” Is there any doubt that a computer is being requested?

You can also <font color=skyblue>test the validity of a leadership claim by a word association test.</font> If the given words are computer, copier, chocolate bar, and cola, the four most associated words are IBM, Xerox, Hershey’s, and Coke.

Also, there’s the <font color=skyblue>halo effect.</font> If you strongly establish one benefit, the prospect is likely to give you a lot of other benefits, too. A “thicker” spaghetti sauce implies quality, nourishing ingredients, value, and so on. A “safer” car implies better design and engineering. Whether the result of a deliberate program or not, most successful companies (or brands) are the ones that “own a word” in the mind of the prospect.

That's why, <font color=skyblue>**once you own the word, go out of your way to protect it in the marketplace.**</font>

But sometimes, you've gotta change words. Sometimes your word does outta style. But down do it in a way where you leave your own word in search of another word that's owned. Think Atari and Nintendo. 

Anti-Drug campaigns sometimes doesn't work. What the campaign ought to do is make drugs what cigarettes are today, socially unacceptable. One word that could do this is the ultimate down word, loser. Since drug usage causes all kinds of losses (of job, family, self-esteem, freedom, life), a program that said “Drugs are for losers” could have a very powerful impact, especially on the recreational user, who is more concerned with social status than with getting high.


# The Law of  Exclusivity: You can't own another person's word
<mark style=background-color:dodgerblue><font color=snow>When a competitor owns a word or position in the prospect's mind, it is futile attempt to own same word.</font></mark>  You can't change someone's mind once it's made up.

As we mentioned earlier, Volvo owns safety. Many other automobile companies, including Mercedes-Benz and General Motors, have tried to run marketing campaigns based on safety. Yet no one except Volvo has succeeded in getting into the prospect’s mind with a safety message.

## Case Study: FedEx vs DHL
Federal Express has walked away from overnight and is in the middle of trying to take worldwide away from DHL. “Overnight Letter” used to be emblazoned on Federal Express envelopes. Today you’ll find “FedEx Letter” instead. And its advertising no longer says, “When it absolutely, positively has to be there overnight.” Lately the word that has been appearing in Federal Express advertising is worldwide. This raises the all-important question: Can Federal Express ever own the worldwide word? Probably not. Someone else already owns it: DHL Worldwide Express. Its concept: Faster to more of the world. To succeed, Federal Express must find a way to narrow the focus against DHL. The company can’t do it by trying to own the same word in the prospect’s mind.

## Case Study: Duracell vs Eveready
Eveready tried to steal long-lasting, but Duracell will always win. Bro... Duracell's got the "Dura" part in its name. Can't win against that. 


# The Law of the Ladder: Your strategy depends on your position
Sometimes you don't need to give up even if you're no.2...or 3. But you've gotta settle and be content with less. The battle isn't lost because <mark style=background-color:dodgerblue><font color=snow>there are strategies to use for no.2 and no.3 brands.</mark></font> Why? Because there are hierarchy in people's mind, like a ladder. 

Sometimes your own ladder, or category, is too small. It might be better to be a small fish in a big pond than to be a big fish in a small pond. In other words, it’s sometimes better to be No. 3 on a big ladder than No. 1 on a small ladder. Before starting any marketing program, ask yourself the following questions: "Where are we on the ladder in the prospect’s mind?", "On the top rung? On the second rung? Or maybe we’re not on the ladder at all." <font color=skyblue>Your marketing strategy should depend on how soon you got into the mind and consequently which rung of the ladder you occupy. The higher the better, of course.</font>

What about your product’s ladder in the prospect’s mind? How many rungs are there on your ladder? It depends on whether your product is a high-interest or a low-interest product. Products you use every day (cigarettes, cola, beer, toothpaste, cereal) tend to be high-interest products with many rungs on their ladders. Products that are purchased infrequently (furniture, lawn mowers, luggage) usually have few rungs on their ladders.

## Case Study: Avis
A car-renting company. Forever no.2, so they accepted their position and went with “Avis is only No. 2 in rent-a-cars. So why go with us? We try harder.” After admitting their position, their sales skyrocketed. 

But after the company was sold, their marketing people was like "let's make Avis No.1". The campaign was a disaster. 

Many marketing people have misread the Avis story. They assume the company was successful because it tried harder (i.e., it had the better service). But that wasn’t it at all. Avis was successful because it related itself to the position of Hertz in the mind.



# The Law of Duality
The ladder will eventually become a two-rung affair. 

When you take the long view of marketing, you find the battle usually winds up as a titanic struggle between two major players—usually the old reliable brand and the upstart.

In batteries, it’s Eveready and Duracell. In photographic film, it’s Kodak and Fuji. In rent-a-cars, it’s Hertz and Avis. In mouthwash, it’s Listerine and Scope. In hamburgers, it’s McDonald’s and Burger King. In sneakers, it’s Nike and Reebok. In toothpaste, it’s Crest and Colgate.

# The Law of Resources 
> Without adequate funding an idea wont get off the ground

We think that we only need a bit of marketing help to get an idea taking off, but nothing could be further from the truth. Marketing is a game fought in the mind of the prospect. You need money to get into a mind. And you need money to stay in the mind once you get there. You’ll get further with a mediocre idea and a million dollars than with a great idea alone.

Advertising is expensive. Rule of thumb: 5-10-20. A small public relations agency will want $5,000 a month to promote your product; a medium-size agency, $10,000 a month; and a big-time agency, $20,000 a month. The giant corporations put a lot of money behind their brands. Procter & Gamble and Philip Morris each spend more than $2 billion a year on advertising. General Motors spends $1.5 billion a year.

Some entrepreneurs see venture capitalists as the solution to their money problems. But only a tiny percentage succeed in finding the funding they need this way. Some entrepreneurs see corporate America as ready, willing, and financially able to get their offspring off the ground. Good luck, you’ll need it. Very few outside ideas are ever accepted by large companies. Your only real hope is finding a smaller company and persuading it of the merits of your idea.

How to get money? 
1. Marry the money 
2. Divorce the money 
3. Find the money at home 
4. Franchise your business 

What about a rich company? How should it approach the law of resources? The answer is simple: Spend enough. In war, the military always errs on the high side. Do you know how many rations were left after Operation Desert Storm? A lot. So it is in marketing. You can’t save your way to success. Money makes the marketing world go round. If you want to be successful today, you’ll have to find the money you need to spin those marketing wheels.

### Tragic Case Study: A&M Pet Products
A&M invented “clumping” cat litter, one of the most important breakthroughs in the category. The concept is simple. When cats use the litter box, this new type of litter clumps the waste into balls, which are easily scooped out and disposed of. There is no need to replace the entire box. The brand, called Scoop Away, took off wherever it was introduced. This quickly got the attention of Golden Cat Corporation, which has the No.1 cat litter brand, Tidy Cat. Recognizing a threatening idea when they see one, Golden Cat introduced their own version of clumping cat litter, called Tidy Scoop. Not only, did they jump on A&M’s idea, they also borrowed the Scoop part of their brand name. (How unfair can you be?) The winner of this cat fight will probably be determined by money. Who has the most money to drive in the idea?





