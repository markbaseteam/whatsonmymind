---
Type: Book Summary
Category: Theology
Author: Joe Rigney
---


# Chapter Summaries
## Chapter 4
In Chapter 4, we unpack the importance of setting our minds on things above, from Colossians 3:1–4. This heavenly mind-set is both oriented by Christ and profoundly earthy, and works itself out in rhythms of direct and indirect god-ward-ness.

In Chapter 3, the author encouraged us to "enjoy the things of earth". But that *sounds* inconsistent with some bible passages. 
<br>The author brought into attention Colossians 3.1-4:
>  If then you have been raised with Christ, seek the things that are above, where Christ is, seated at the right hand of God. Set your minds on things that are above, not on things that are on earth. For you have died, and your life is hidden with Christ in God. When Christ who is your  life appears, then you also will appear with him in glory.

<br> However, the apparent contradiction can be solved by understanding the passage rightly. To do that, we need to understand what Paul means by "things on earth" and "set your mind". 

<mark style=background-color:crimson><font color=snow>What does Paul mean by "things on earth"?</mark></font> Does he mean things like baseball, bacon cheeseburgers, game nights with the family, Shakespeare, working out, Star Wars, home repairs, and church picnics on sunny days? Does that mean that we cannot set our mind on them in any sense? The answer is in the verse later: 
>  Put to death therefore what is earthly in you:  sexual immorality, impurity, passion, evil desire, and covetousness, which is idolatry. On account of these the wrath of God is coming.

"Things on earth" doesn't mean everything, but "sinful things". 

<mark style=background-color:crimson><font color=snow>What does Paul mean by "set your mind on"?</mark></font> 
Observe how Paul mean by his use of the "mind" language. 

>  <u>Philippians 3:18-19</u>
>  For many, of whom I have often told you and now tell you even with tears, walk as enemies of the cross of Christ. Their end is destruction, their god is their belly, and they glory in their shame, with minds set on earthly things.

><u>Philippians 4:8</u> 
>  Finally, brothers, whatever is true, whatever is honorable, whatever is just, whatever is pure, whatever is lovely, whatever is commendable, if there is any excellence, if there is anything worthy of praise, think about these things.

The Greek word for “think” in this passage (logizomai) is different from the word for “setting your mind on” in the other passages (phroneo). And if we reflect upon the difference between them, a picture begins to emerge. Paul is saying that all of us have a fundamental orientation of the heart, what he calls a mind-set. That mind-set and orientation ought to be governed by the things above, where Christ is. If we orient our lives by Christ, then we’re free to think, to consider, to attend to whatever is true, good, and beautiful wherever we find it, whether in heaven or on earth. To put it succinctly, we set our minds on things above and then consider what is good and lovely in things below.

In other words, Paul is calling us to a life centered on Christ, rooted and grounded in God’s love, and oriented by the glory and majesty and beauty of God. Because we’ve died with Christ, because our life is now hidden with him (Col. 3:3), therefore we must fix the fundamental direction of our minds and hearts on him always.

But we have to define always the way the Bible does. And this is where we often go wrong. We adopt a narrow and truncated picture of the mind that is set on things above. We think that a heavenly mind-set means we only do spiritual activities such as prayer and Bible reading. But if we look at Paul’s description of the faithful Christian life in the rest of Colossians 3, we’ll see just how earthy the heavenly mind-set is:

Put on humility and meekness like a new robe (3:12); be patient and forgive each other (3:13); wear your love on your sleeve and watch it compose a symphony (3:14); put peace on the throne of your heart; and be thankful (3:15). Make the Scriptures at home in your soul. Teach and sing them to each other with thankfulness in your heart (3:16); do everything in the name of Jesus. And did I mention give thanks to God (3:17)? Wives, submit to your husbands (3:18); husbands, love your wives (3:19). Children, obey your parents; it makes God happy (3:20). Fathers, don’t provoke your children; that doesn’t make God happy (3:21). Are you under authority? Then obey those over you sincerely because you fear God (3:22). Do your work with gusto, because God will reward you (3:23–24). Are you in authority? Then be just and fair to those in your care, because you have a boss in heaven (4:1). Pray without ceasing. And, seriously, did I mention be grateful (4:2)? Pray that the missionaries would be fruitful and bold (4:3–4). Show the world how the wise walk by taking time away from the devil (4:5). Use salty language, the kind that gives grace (4:6).

According to Paul, the heavenly mind-set spends a lot of time thinking about and engaging with things on the earth. Family, neighbors, church, job, earthly joys—the person whose mind-set is governed by heavenly things intentionally and deliberately considers and engages them. The heavenly mindset is profoundly earthly, but it is fundamentally oriented by the risen Christ. 

But orienting your life by Christ doesn’t simply mean making him the supreme object of your desire; it also means making him the supreme model for your desires. When our minds are set on Christ, on the things above, then all our other desires are ordered properly. It’s not just that we love him; it’s that we love everything else that we love in him. Which means we love them in the way that he wants us to love them. In other words, setting your mind on things above means that you love God and that you love what God loves, that you supremely desire God and rightly desire everything that God desires.

In other words, we take our cues from him so that he sets the boundaries and the contexts for our enjoyment of sex or creation or culture or whatever. He becomes the sun at the center of our solar system that makes all the planets orbit properly.

Now let’s get practical by drawing together a few threads from this chapter and the ones before it. Begin with the fundamental truth that creation shows us what God is like. His invisible attributes are clearly perceived in the things that have been made. Now follow this basic logic. 1. Made things make invisible attributes visible. 2. You are a made thing. 3. Therefore, you make invisible attributes visible. You are a word from God. God means something through you. You are communication from God about God, just like the heavens. Your conduct, your life, is itself a kind of divine speech. It is revelation from God, designed by him to show the world what he is like. Here’s how this basic truth challenges me personally: Will I tell the truth about God or will I lie? Will God teach others about himself through me by way of comparison or by way of contrast? Everyone is going to glorify God one way or another. Either God will point at us and say, “I am something like that. That, even with all the flaws, is a little picture of what I’m like.” Or he will point at us and say, “That’s the opposite of what I’m like. I’m not that kind of husband. I’m not that kind of father. I’m not that kind of friend.”

## Chapter 5
The chapter explores the comparative tests that guards us from falling into covetousness, greed and idolatry: 
1. Self-denial 
2. Generosity

# Chapter 6
Guilt, anger, frustration
1. Press into the pain 
2. Press into people
3. Press into the Lord