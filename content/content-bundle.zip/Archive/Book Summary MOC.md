```dataview
TABLE Category, Author
FROM "Garden/Archive/Book Summaries"
```
