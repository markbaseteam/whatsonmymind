# Ideas:
## Digital Art-related
1. Sell Printables
2. Sell Digital Templates
3. Sell Design Templates
4. Sell Brushes, Textures, Etc. 
5. Print-on-Demand 
6. Photography Service 
7. Making overlays

Read: 
[Selling Canva Templates](https://www.thesideblogger.com/how-to-sell-canva-templates/)
[Where to sell Templates](https://learnwoo.com/where-to-sell-templates-marketplaces/)

## Creatives
1. Pottery 


## Rent
- AirBnB

## Platforms:
### POD
1. Artspan
2. Artpal
3. Cafepress
4. Fineartamerica
5. Printful
6. Printify
7. Redbubble
8. Zazzle

### Where to sell 
1. Creative Market 
2. Etsy
3. Design cuts
4. Creative Fabrica
5. Dribble
6. GumRoad

### Selling on your own Platform
1. Shopify
2. Ko-fi



# Case Studies
## Augu's Side Hustle
![[Augu's Side Hustle]]

# The Technicalities
## Keyword Analytics
- EverBee
- 
# Helpful Resources:
## Videos
https://www.youtube.com/watch?v=WpW34_KCSU4