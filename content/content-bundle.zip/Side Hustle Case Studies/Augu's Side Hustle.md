## Augustine's Etsy Side Hustle: 
He's running an Etsy stores selling T shirts, Sweatshirts, and Hoodies. He either create designs or hire designers, then place those designs on templates from Printify, then list them at his Etsy Store. Printify handles the printing and shipping. He earns the difference as profit. 

## What Augu said:
"For my Etsy I'm doing something different. I'm doing <mark style=background-color:crimson><font color=snow>print on demand</mark></font> ~ focused on selling T-shirts, Sweatshirts and Hoodies"

I create designs on my own or hire designers then place those designs on product templates from a company that provides print on demand product blanks (Printify) then list them on my Etsy store.

When a customer buys, My printify receives the order from my backend and I then fulfill it and Printify ships the order directly to my customers. Printify charges me for the cost of the product blanks and I earn the difference as profit. 

( Eg: Customer pays me $28 for a t-shirt, the cost of printing the order = $12 + the cost from Etsy transaction fees = 20% of what customer paid. I then earn the difference from that order as profit)

It's like clothing dropshipping basically. 

Whereas for selling digital products on Etsy, your only cost is the etsy transaction fees + your subscription to Canva Pro and the keyword research website (Which is pretty minimal)

My cost consists of (Printify monthly subscription + keyword research website + Photoshop + Canva Pro + Designer cost)

Last month was my best month so far, I made around RM3-4K profit

it takes research, honing in on the data analytics, so, etc
So gotta set appropriate expectations, 

I had the wrong expectations earlier on because I wanted to pay off my debts quickly and I thought just because my designs feel better I'll sell like hot cakes so I almost gave up when my first few months last year were slow



